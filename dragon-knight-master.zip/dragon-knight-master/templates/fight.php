<?php
$template = <<<THEVERYENDOFYOU
<table width="100%">
<tr><td class="title"><img src="images/title_fighting.gif" alt="Fighting" /></td></tr>
<tr><td>
You are fighting a <b>{{monstername}}</b><br /><br />
{{monsterhp}}
{{yourturn}}
{{monsterturn}}
{{command}}
</td></tr>
</table>
THEVERYENDOFYOU;
?>